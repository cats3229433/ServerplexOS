import { expect, test } from 'vitest';
import { HiFiClient, TidalResponse } from './HiFi';
import type { Album, PlaybackInfo, Track } from './container-classes';

const ARTIST_ID = 3523908; // deadmau5
const ALBUM_ID = 433360012; // deadmau5 - 4x4=12
const _ALBUM_ATMOS = 463900719; // Taylor Swift - The Life of a Showgirl
const TRACK_ATMOS = 463900720; // Taylor Swift - The Fate of Ophelia
const _TRACK_NO_LOSSLESS = 31097959; // deadmau5 - while(1<2)
const TRACK_VIDEO = 466464180; // Taylow Swift - The Fate of Ophelia
const TRACK_LOSSLESS = 31097949; // deadmau5 - Avaritia
const PLAYLIST_ID = '36ea71a8-445e-41a4-82ab-6628c581535d'; // Pop Hits

const instance = new HiFiClient();
await instance.fetchToken();

// Live-network integration tests hit the real Tidal backend, which is
// unavailable/flaky in CI (404/523). Skip them in CI; they still run locally.
const skipLiveNetwork = !!process.env.CI;

function checkVersion({ version }: { version?: string }) {
    expect(version).toBeTypeOf('string');
    expect(version).not.equals('');
    expect(version).equals(HiFiClient.API_VERSION);
}

async function _getJson(res: Response | Promise<Response>) {
    res = await res;
    expect(res).toBeInstanceOf(Response);
    expect(res.ok).toBeTruthy();
    return (await res.json()) as object;
}

async function checkRoute(
    route: string,
    routeResult: () => Promise<Response>,
    checks: (data: object) => Promise<void>,
    mainKey: string | null = 'data'
) {
    const routeData = await instance.query(route);
    const routeRes = (await routeResult()) as unknown;
    expect(routeData).toBeInstanceOf(TidalResponse);
    expect(routeData).toEqual(routeRes);

    const json = (await routeData.json()) as object;
    checkVersion(json);

    if (mainKey != null) {
        expect(json).toHaveProperty(mainKey);
        expect(json[mainKey]).not.toBeUndefined();
    }

    await checks(json);
}

test('Get token', async () => {
    const instance = new HiFiClient();

    const token = await instance.fetchToken();
    expect(token).toBeTypeOf('string');
    expect(token).not.toBeUndefined();
    expect(token).not.length(0);
    expect(token).equals(instance.token);

    const token2 = await instance.fetchToken(true);
    expect(token2).toBeTypeOf('string');
    expect(token2).not.toBeUndefined();
    expect(token2).not.length(0);
    expect(token2).equals(instance.token);
    expect(token2).not.equals(token);

    expect(instance.appTokenExpiry).toBeGreaterThan(Date.now());
});

test.skipIf(skipLiveNetwork)('Fetch atmos track info', async () => {
    await checkRoute(
        `/info/?id=${TRACK_ATMOS}`,
        () => instance.getInfo(TRACK_ATMOS),
        async (info: { data: Track }) => {
            expect(info.data.audioModes).toContain('DOLBY_ATMOS');
        }
    );
});

test.skipIf(skipLiveNetwork)('Fetch track', async () => {
    await checkRoute(
        `/track/?id=${TRACK_LOSSLESS}`,
        () => instance.getTrack(TRACK_LOSSLESS),
        async (track: { data: PlaybackInfo }) => {
            expect(track?.data?.trackId).toBe(TRACK_LOSSLESS);
            expect(track.data.assetPresentation).toBeTypeOf('string');
            expect(track.data.audioQuality).toBeTypeOf('string');
            expect(track.data.manifestMimeType).toBeTypeOf('string');
            expect(track.data.manifestHash).toBeTypeOf('string');
            expect(track.data.manifest).toBeTypeOf('string');
            expect(track.data.albumReplayGain).toBeTypeOf('number');
            expect(track.data.albumPeakAmplitude).toBeTypeOf('number');
            expect(track.data.trackReplayGain).toBeTypeOf('number');
            expect(track.data.trackPeakAmplitude).toBeTypeOf('number');
            expect(track.data.bitDepth).toBeTypeOf('number');
            expect(track.data.sampleRate).toBeTypeOf('number');
        }
    );
});

test.skipIf(!instance.refreshToken)('Fetch recommendations', async () => {
    await checkRoute(
        `/recommendations/?id=${ARTIST_ID}`,
        () => instance.getRecommendations(ARTIST_ID),
        async (_data) => {}
    );
});

test.skipIf(skipLiveNetwork)('Fetch similar artists', async () => {
    await checkRoute(
        `/artist/similar/?id=${ARTIST_ID}`,
        () => instance.getSimilarArtists(ARTIST_ID),
        async (_data) => {},
        'artists'
    );
});

test.skipIf(skipLiveNetwork)('Fetch similar albums', async () => {
    await checkRoute(
        `/album/similar/?id=${ALBUM_ID}`,
        () => instance.getSimilarAlbums(ALBUM_ID),
        async (_data) => {},
        'albums'
    );
});

test.skipIf(skipLiveNetwork)('Fetch artist info', async () => {
    await checkRoute(
        `/artist/?id=${ARTIST_ID}`,
        () => instance.getArtist(ARTIST_ID),
        async (info: {
            cover: string;
            tracks: Array<{ duration?: number }>;
            albums: { items: Array<{ duration?: number }> };
        }) => {
            expect(info).toHaveProperty('cover');
            expect(info.cover).not.toBeUndefined();

            // Verify track durations are parsed from ISO 8601, not hardcoded to 100
            if (Array.isArray(info.tracks) && info.tracks.length > 0) {
                const withDuration = info.tracks.filter((t) => typeof t.duration === 'number');
                expect(withDuration.length).toBeGreaterThan(0);
                const allAre100 = withDuration.every((t) => t.duration === 100);
                expect(allAre100).toBe(false);
            }

            // Verify album durations are also parsed, not hardcoded to 100
            if (info.albums?.items?.length > 0) {
                const withDuration = info.albums.items.filter((a) => typeof a.duration === 'number');
                if (withDuration.length > 0) {
                    const allAre100 = withDuration.every((a) => a.duration === 100);
                    expect(allAre100).toBe(false);
                }
            }
        },
        'artist'
    );
});

test.skipIf(skipLiveNetwork)('Search', async () => {
    const query = 'deadmau5';
    await checkRoute(
        `/search/?q=${encodeURIComponent(query)}`,
        () =>
            instance.search({
                q: query,
            }),
        async (_res) => {}
    );
});

test.skipIf(skipLiveNetwork)('Fetch album info', async () => {
    await checkRoute(
        `/album/?id=${ALBUM_ID}`,
        () => instance.getAlbum(ALBUM_ID),
        async (info: { data: Album }) => {
            expect(info.data).toHaveProperty('cover');
            expect(info.data.cover).not.toBeUndefined();
        }
    );
});

test.skipIf(skipLiveNetwork)('Fetch playlist info', async () => {
    await checkRoute(
        `/playlist/?id=${PLAYLIST_ID}`,
        () => instance.getPlaylist(PLAYLIST_ID),
        async (info: { playlist: { image: string } }) => {
            expect(info.playlist).toHaveProperty('image');
            expect(info.playlist.image).not.toBeUndefined();
        },
        'playlist'
    );
});

test.skipIf(!instance.refreshToken)('Fetch lyrics ', async () => {
    await checkRoute(
        `/lyrics/?id=${TRACK_ATMOS}`,
        () => instance.getLyrics(TRACK_ATMOS),
        async (_info) => {},
        'lyrics'
    );
});

test.skipIf(skipLiveNetwork)('Fetch video ', async () => {
    await checkRoute(
        `/video/?id=${TRACK_VIDEO}`,
        () => instance.getVideo(TRACK_VIDEO),
        async (_info) => {},
        'video'
    );
});

test.skipIf(skipLiveNetwork)('Fetch track manifests ', async () => {
    await checkRoute(
        `/trackManifests/?id=${TRACK_LOSSLESS}`,
        () => instance.getTrackManifest(TRACK_LOSSLESS),
        async (_info) => {},
        'data'
    );
});
