import { expect, test, describe, beforeEach, vi } from 'vitest';
import {
    recentActivityManager,
    themeManager,
    lastFMStorage,
    nowPlayingSettings,
    gaplessPlaybackSettings,
    disableBlurEffectsSettings,
    exponentialVolumeSettings,
    audioEffectsSettings,
    silenceRemovalSettings,
    crossfadeSettings,
    donationPromptSettings,
} from '../storage.js';

describe('storage.js', () => {
    beforeEach(() => {
        localStorage.clear();
        document.documentElement.classList.remove(disableBlurEffectsSettings.ROOT_CLASS);
        vi.clearAllMocks();
    });

    describe('recentActivityManager', () => {
        test('initializes with empty arrays', () => {
            const recents = recentActivityManager.getRecents();
            expect(recents.artists).toEqual([]);
            expect(recents.albums).toEqual([]);
        });

        test('adds artist and maintains limit', () => {
            for (let i = 0; i < 15; i++) {
                recentActivityManager.addArtist({ id: i, name: `Artist ${i}` });
            }
            const recents = recentActivityManager.getRecents();
            expect(recents.artists.length).toBe(10);
            expect(recents.artists[0].id).toBe(14);
        });

        test('clears recents', () => {
            recentActivityManager.addArtist({ id: 1, name: 'Artist' });
            recentActivityManager.clear();
            const recents = recentActivityManager.getRecents();
            expect(recents.artists).toEqual([]);
        });
    });

    describe('themeManager', () => {
        test('gets and sets theme', () => {
            themeManager.setTheme('dark');
            expect(themeManager.getTheme()).toBe('dark');
            expect(document.documentElement.getAttribute('data-theme')).toBe('dark');
        });

        test('handles custom theme', () => {
            const colors = { primary: '#ff0000', background: '#000000' };
            themeManager.setCustomTheme(colors);
            expect(themeManager.getTheme()).toBe('custom');
            expect(themeManager.getCustomTheme()).toEqual(colors);
            expect(document.documentElement.style.getPropertyValue('--primary')).toBe('#ff0000');
        });
    });

    describe('lastFMStorage', () => {
        test('handles enabled state', () => {
            lastFMStorage.setEnabled(true);
            expect(lastFMStorage.isEnabled()).toBe(true);
            lastFMStorage.setEnabled(false);
            expect(lastFMStorage.isEnabled()).toBe(false);
        });

        test('obfuscates sensitive data', () => {
            const key = 'test-api-key';
            lastFMStorage.setCustomApiKey(key);
            expect(localStorage.getItem(lastFMStorage.CUSTOM_API_KEY)).not.toBe(key);
            expect(lastFMStorage.getCustomApiKey()).toBe(key);
        });
    });

    describe('nowPlayingSettings', () => {
        test('gets and sets mode', () => {
            expect(nowPlayingSettings.getMode()).toBe('cover');
            nowPlayingSettings.setMode('visualizer');
            expect(nowPlayingSettings.getMode()).toBe('visualizer');
        });
    });

    describe('gaplessPlaybackSettings', () => {
        test('defaults to true', () => {
            expect(gaplessPlaybackSettings.isEnabled()).toBe(true);
        });

        test('sets enabled state', () => {
            gaplessPlaybackSettings.setEnabled(false);
            expect(gaplessPlaybackSettings.isEnabled()).toBe(false);
        });
    });

    describe('disableBlurEffectsSettings', () => {
        test('defaults to disabled and applies its persisted state to the document', () => {
            expect(disableBlurEffectsSettings.isEnabled()).toBe(false);
            expect(document.documentElement.classList.contains(disableBlurEffectsSettings.ROOT_CLASS)).toBe(false);

            disableBlurEffectsSettings.setEnabled(true);
            expect(localStorage.getItem(disableBlurEffectsSettings.STORAGE_KEY)).toBe('true');
            expect(document.documentElement.classList.contains(disableBlurEffectsSettings.ROOT_CLASS)).toBe(true);

            disableBlurEffectsSettings.setEnabled(false);
            expect(localStorage.getItem(disableBlurEffectsSettings.STORAGE_KEY)).toBe('false');
            expect(document.documentElement.classList.contains(disableBlurEffectsSettings.ROOT_CLASS)).toBe(false);
        });

        test('restores the document class from a persisted preference', () => {
            localStorage.setItem(disableBlurEffectsSettings.STORAGE_KEY, 'true');
            disableBlurEffectsSettings.apply();

            expect(document.documentElement.classList.contains(disableBlurEffectsSettings.ROOT_CLASS)).toBe(true);
        });

        test('notifies blur consumers when the preference changes', () => {
            let detail;
            const onChange = (event) => {
                detail = event.detail;
            };
            window.addEventListener('disable-blur-effects-changed', onChange);

            disableBlurEffectsSettings.setEnabled(true);

            expect(detail).toEqual({ enabled: true });
            window.removeEventListener('disable-blur-effects-changed', onChange);
        });
    });

    describe('silence removal and crossfade settings', () => {
        test('defaults to silence removal on and crossfade off', () => {
            expect(silenceRemovalSettings.isEnabled()).toBe(true);
            expect(crossfadeSettings.isEnabled()).toBe(false);
        });

        test('migrates the former combined toggle to both independent controls', () => {
            localStorage.setItem('smart-silence-skip-enabled', 'true');

            expect(silenceRemovalSettings.isEnabled()).toBe(true);
            expect(crossfadeSettings.isEnabled()).toBe(true);
        });

        test('stores independent enabled states and an adjustable duration', () => {
            silenceRemovalSettings.setEnabled(false);
            crossfadeSettings.setEnabled(true);
            crossfadeSettings.setDuration(8);

            expect(silenceRemovalSettings.isEnabled()).toBe(false);
            expect(crossfadeSettings.isEnabled()).toBe(true);
            expect(crossfadeSettings.getDuration()).toBe(8);
        });

        test('clamps crossfade duration to the supported range', () => {
            crossfadeSettings.setDuration(30);
            expect(crossfadeSettings.getDuration()).toBe(12);
            crossfadeSettings.setDuration(0);
            expect(crossfadeSettings.getDuration()).toBe(5);
        });
    });

    describe('donation prompt settings', () => {
        test('defaults reminders on and persists an opt-out', () => {
            expect(donationPromptSettings.isEnabled()).toBe(true);
            donationPromptSettings.setEnabled(false);
            expect(donationPromptSettings.isEnabled()).toBe(false);
        });
    });

    describe('exponentialVolumeSettings', () => {
        test('applies curve when enabled', () => {
            exponentialVolumeSettings.setEnabled(true);
            expect(exponentialVolumeSettings.applyCurve(0.5)).toBeCloseTo(0.125);
            expect(exponentialVolumeSettings.inverseCurve(0.125)).toBeCloseTo(0.5);
        });

        test('does not apply curve when disabled', () => {
            exponentialVolumeSettings.setEnabled(false);
            expect(exponentialVolumeSettings.applyCurve(0.5)).toBe(0.5);
            expect(exponentialVolumeSettings.inverseCurve(0.5)).toBe(0.5);
        });
    });

    describe('audioEffectsSettings', () => {
        test('gets and sets speed within bounds', () => {
            audioEffectsSettings.setSpeed(2.0);
            expect(audioEffectsSettings.getSpeed()).toBe(2.0);

            audioEffectsSettings.setSpeed(200);
            expect(audioEffectsSettings.getSpeed()).toBe(100);

            audioEffectsSettings.setSpeed(0);
            expect(audioEffectsSettings.getSpeed()).toBe(0.01);
        });

        test('resets speed', () => {
            audioEffectsSettings.setSpeed(2.0);
            audioEffectsSettings.resetSpeed();
            expect(audioEffectsSettings.getSpeed()).toBe(1.0);
        });
    });
});
